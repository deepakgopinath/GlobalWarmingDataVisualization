import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import shapes3d.utils.*; 
import shapes3d.animation.*; 
import shapes3d.*; 

import shapes3d.utils.*; 
import shapes3d.animation.*; 
import shapes3d.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class CarbonDioxideVisualization extends PApplet {

                    //*******************Carbon Dioxide Emission Visualization*******************//
                    //*****************by DEEPAK GOPINATH******************//
                    
                    //************* Project 2 - Navigable Info ***************//
                    //********************  LMC 6310 ***********************//




 // For rendering the earth



// ATTENTION: YOU NEED TO HAVE SHAPES3D.JAR IN YOUR CODE FOLDER
//Declaration of variables

Ellipsoid earth;
int earthRad = 90;

String currentCountry = "";
String previousCountry = "";
int countryCounter = -1;

int noOfCountries = 209;
int noOfYears = 53;

float [][] dataCO2PerCapita = new float[noOfCountries][noOfYears]; // ARRAY TO HOLD CO2 DATA AND LATITUDE LONGITUDE DATA
float [][] latLong = new float[noOfCountries][2];
float [][] dataCO2Total = new float[noOfCountries][noOfYears];

float zoomFactor = 2.5f;
float cameraDist = 280;

ArrayList <ParticleSystem> ps; // FOR SMOKE LIFE EFFECT
ArrayList <ParticleSystem> ps2;

ParticleSystem eachPS; // USED IN FOR LOOPS TO KEEP TRACK OF SMOKE EFFECTS

float theta  = 0;
float phi = 0;
float thetaInc = 0;
float phiInc = 0;
float lati;
float longi;

float longiInc = 180; // Longitude phase shift to correct for 3d geometry.
int yearSelected = 1960; //starting year
float histLength = 0; // starting histlength

ArrayList yearlyNewsList = new ArrayList();

int readStatus = 0; //for the marquee
int selectNewsItemForCurrentYear = 0;
int lengthOfString = 0;
int index = 0;
String eachNewsItem;

int CO2TotalSelect = 0;
int CO2PerCapita = 1;
int smokeMode = 0;
int switchMode = 0;
int darkFuture = 0;
int scaleFactor = 12000;
int startFlag;
PImage img; // FOR THE SMOKE PARTICLE

String currentCountryData = "";
String enteredCurrentText = "";
String savedText = "";
ArrayList countryList = new ArrayList();


public Ellipsoid AddEllipsoid(int nbrSlices, int nbrSegments, String textureFile, float radius)
{
  Ellipsoid aShape = new Ellipsoid(this, nbrSlices, nbrSegments);
  aShape.setTexture(textureFile);
  aShape.drawMode(Shape3D.TEXTURE);
  aShape.setRadius(radius);
  return aShape;
  
}

public void setup()
{
  size(1024,768, P3D);
  background(0);
  frameRate(60);
  stroke(255);
  strokeWeight(1);
  earth = AddEllipsoid(14,14,"Earth.jpg",earthRad); //MAKE THE EARTH
  
  loadCarbonDioxideData(); //LOAD DATA FROM XML
  loadCO2TotalData();
  loadLatLongData();
  loadCountryData();
  loadNewsItems();
  
  ps = new ArrayList();
  ps2 = new ArrayList();
  tweakImage();
  for (int i=0; i<noOfCountries; i++) // MAKE SMOKE FOR EACH COUNTRY AND EACH KIND OF DATA POINT USING DATA FROM 1960 AS DEFAULT
  {
    ps.add(new ParticleSystem(7 + (int)random(6), new PVector(earthRad + 5*dataCO2PerCapita[i][yearSelected - 1960],0), img));
    ps2.add(new ParticleSystem(7 + (int)random(6), new PVector(earthRad + dataCO2Total[i][yearSelected - 1960]/scaleFactor,0), img));
  }
   textAlign(LEFT);
   textSize(18);
  
}

public void tweakImage()
{
   img = loadImage("textureEvenSmaller.png");
   img.filter(BLUR);  
}
public void draw()
{
  background(0);
  
  if(startFlag == 0)
  {
   displayFirstPage();
  }else if(startFlag == 1)
  {
    displaySecondPage();
  } else if(startFlag > 1) {
  
  readNews();
  drawSelectorButtons();
  text("Current Year:", 810, 125);
  text(yearSelected, 950, 125);
  
  theta = theta + thetaInc; // keeping track of rotation. these angle info is used to position the camera properly.
  phi = phi + phiInc;
  checkAngles(); //check bounds for angles.
  
  pushMatrix();
  translate(width/2,height/2, 0);
  directionalLight(255, 255,255, 0, 0, -1); // Set up some directional lighting. White Light shining from -z direction
  lightSpecular(204, 204, 204);
  directionalLight(255, 255, 255, 0, 1, -1);  
  lightSpecular(202, 202, 202);
  
  for(int i=0; i<noOfCountries; i++)
  {
    lati = radians(latLong[i][0]);
    longi = radians(latLong[i][1] + longiInc);
    
    if(CO2TotalSelect == 1){
      eachPS = (ParticleSystem)ps2.get(i);
    }else if(CO2PerCapita == 1){
       eachPS = (ParticleSystem)ps.get(i);
    }
    beginCamera();
    camera(cameraDist*zoomFactor*sin(theta)*abs(cos(phi)), cameraDist*zoomFactor*sin(phi), cameraDist*zoomFactor*cos(theta)*abs(cos(phi)), 0 ,0 ,0, 0, 1, 0);
    
    if(CO2PerCapita == 1)
      { 
        histLength =   5*dataCO2PerCapita[i][yearSelected - 1960]; // Scale data point by multiplying by 5. 
      }else if (CO2TotalSelect == 1)
      {
        histLength = dataCO2Total[i][yearSelected - 1960]/scaleFactor;
      }
   
      fill(255);
      if(darkFuture != 1)
      {
        earth.draw();
      }
      pushMatrix();
      rotateY(longi); //Get to the correct country
      rotate(-lati);

      if(smokeMode == 1){
        if(switchMode == 1)
        {
          eachPS.changeOrigin(new PVector(histLength,0));
        }
        eachPS.run(histLength);
        for(int k =0 ; k< 2; k++)
        {
        eachPS.addParticle();
        }
      }
      
      translate(earthRad+histLength/2,0,0); //translate after writing the text. // So that the histogram gets drawn properly  
      fill(random(200) + 55,0,0);
      stroke(255,0,0);
      strokeWeight(0.2f);
      box(histLength, 3,3);
      popMatrix();
    endCamera();
   
  }
  if(switchMode == 1)
  {
    switchMode = 0;
  }
  popMatrix();
  
  thetaInc *= 0.5f; // decelerate rotating angles for camera
  phiInc *= 0.5f;
  if(mousePressed){
     
     thetaInc -= (mouseX-pmouseX)*0.01f;
     phiInc -= (mouseY-pmouseY)*0.01f;
   }
  }
}

public void checkAngles()
{
  if(phi >= PI/2)
  {
    phi = PI/2 - 0.01f;
  }else if(phi <= -PI/2)
  {
    phi = -PI/2 + 0.01f;
  }
}


public void displayFirstPage()
{
    fill(255,25, 0);
    textAlign(CENTER);
    textSize(38);
    text("CarbOn DiOxIDE EMissION VisuALiZaTion", width/2 , height/2 - 100);
    textSize(22);
    text("CrEAted bY", width/2, height/2 - 40);
    textSize(28);
    text("DeEpaK goPiNatH", width/2, height/2 + 15 );
    textSize(20);
    fill(255,255,0);
    text("Hit Space to Continue", width/2, height/2 + 170);
}

public void displaySecondPage()
{
    fill(255, 25, 0);
    textAlign(CENTER);
    textSize(30);
    text("Navigation", width/2, height/2 - 150);
    textSize(18);
    
    text("Use the mouse to rotate the globe", width/2, height/2 - 40);
    text("Use up and down arrows to control the zoom level", width/2, height/2 + 20);
    text("Use left and right arrows to select the year", width/2, height/2 + 80);
    
    fill(255,255,0);
    textSize(20);
    text("Hit Space to Continue", width/2, height/2 + 170);
    textAlign(LEFT);
    textSize(18);
}

public void displayData()
{
    
  for(int i=0; i<countryList.size(); i++)
  {
    String eachItem = (String)countryList.get(i);
    if(eachItem.equals(trim(savedText.toLowerCase())))
    {
     // println("The data is " + dataCO2PerCapita[i][yearSelected - 1960]);
      if(CO2PerCapita ==  1 && CO2TotalSelect == 0)
      {
        if(dataCO2PerCapita[i][yearSelected - 1960] != 0)
        {
          currentCountryData = str(dataCO2PerCapita[i][yearSelected - 1960]);
        }else{  
        currentCountryData = "Not Available";
        }
      }else if (CO2PerCapita ==  0  && CO2TotalSelect == 1)
      {
        if(dataCO2Total[i][yearSelected - 1960] != 0)
        {
           currentCountryData = str(dataCO2Total[i][yearSelected - 1960]);
        }else{
        currentCountryData = "Not Available";
        }
      }
      break;
    }
  }
}



public void readNews()
{
    fill(255);
    if(readStatus == 0){
    ArrayList eachYearItemList = (ArrayList)yearlyNewsList.get(yearSelected - 1960);
    readStatus = 1;
    selectNewsItemForCurrentYear = (int)random(eachYearItemList.size());
    if(selectNewsItemForCurrentYear > 0){
    eachNewsItem = (String)eachYearItemList.get(selectNewsItemForCurrentYear);
    lengthOfString = eachNewsItem.length();
   }else {
     eachNewsItem = "  ";
     lengthOfString = eachNewsItem.length();
   }
  }
  
  text(eachNewsItem.substring(index,lengthOfString), 220, 60);
   if(frameCount%3 == 0)
    {   
      index += (int)(40/frameRate);
      if(index >= lengthOfString - 1){
        index = 0;
        readStatus = 0;
        
      }
    }
}

public void drawSelectorButtons()
{
  fill(0);
  stroke(0,255,0);
  strokeWeight(2);
  rect(1000, 200, 20,20); 
  rect(1000, 240, 20, 20);
  rect(1000, 280, 20, 20);
  rect(1000, 320, 20, 20);
  rect(790, 530, 230, 30); 
  rect(790, 600, 230, 30);

  
  fill(255,0,0);
  text("Per Capita Emissions", 810, 215);
  text("Total Emissions", 810, 255);
  text("Burning Planet", 810,295);
  text("The Dark Future", 810, 335);
  text("Country Search", 650, 550);
  text(savedText, 795, 550);
  text("Current Data", 670, 620);
  text(currentCountryData, 795, 620);
  

  if (CO2PerCapita == 1 && CO2TotalSelect == 0)
  {
    text("X", 1005, 215);
    text(" ", 1005, 255);
  }
  if (CO2PerCapita == 0 && CO2TotalSelect == 1)
  {
    text(" ", 1005, 215);
    text("X", 1005, 255);
  }
  if(smokeMode == 1)
  {
    text("X", 1005, 295);
  }else if(smokeMode == 0);
  {
    text(" ", 1005, 295);
  }
  if( darkFuture == 1)
  {
    text("X", 1005, 335);
    
  }else if(darkFuture == 0)
  {
    text(" ", 1005, 335);
  }
  stroke(255);
  
}




public void keyPressed() // up and down arrows to control the zooming in and out.
{
  if(key == ' ')
  {
    startFlag += 1;
  }
  if(key != CODED)
  { // Keeping track of text entry. Backspace clears the string character by character. Enter retreives the data and displays it the data box. 
    switch(key)
    {
      case BACKSPACE :
        enteredCurrentText = enteredCurrentText.substring(0, max(0,enteredCurrentText.length()-1));
        savedText = enteredCurrentText;
        currentCountryData = ""; //Clear the data display field
        break;
      case ENTER:
      case RETURN:
        savedText = enteredCurrentText;
        displayData();
        break;
       default:
         enteredCurrentText += key;
         savedText = enteredCurrentText;
         currentCountryData = "";
         break;
        
    }
  }else if(key == CODED){
    if(keyCode == UP){
      zoomFactor = zoomFactor - 0.01f;
      if(zoomFactor <= 0.7f){
        zoomFactor = 0.7f;
      }
        
    } else if(keyCode == DOWN){
     zoomFactor = zoomFactor + 0.01f;
      if(zoomFactor >= 2.5f){
        zoomFactor = 2.5f;
      }
    }else if(keyCode == RIGHT){
      switchMode = 1;
      yearSelected = yearSelected + 1; 
      if(yearSelected >= 2009){
        yearSelected = 2009;
      }
      displayData();
    }else if(keyCode == LEFT){
      switchMode = 1;
      yearSelected = yearSelected - 1; 
      if(yearSelected <= 1960){
        yearSelected = 1960;
      }
      displayData();
    }
  }
    
}

public void mouseReleased()
{
  //To see if the mouse was clicked in the selector boxes.
  
  if((mouseX >= 1000 && mouseX <= 1020) && (mouseY > 200 && mouseY < 220))
  {
    CO2PerCapita = 1; // Setting flags for which data set to access
    CO2TotalSelect = 0;
    displayData();
  }else if((mouseX >= 1000 && mouseX <= 1020) && (mouseY > 240 && mouseY < 260))
  {
    CO2PerCapita = 0;
    CO2TotalSelect = 1;
    displayData();
  }else if((mouseX >= 1000 && mouseX <= 1020) && (mouseY > 280 && mouseY < 300))
  {
    if(smokeMode == 0)
    {
      smokeMode = 1;
    }
    else
    {
      smokeMode = 0;
    }
  }else if((mouseX >= 1000 && mouseX <= 1020) && (mouseY > 320 && mouseY < 340))
  {
    if(darkFuture == 0)
    {
      darkFuture = 1;
    }
    else
    {
      darkFuture = 0;
    }
  }
}
//All the xml parsing code goes in here. 

public void loadCarbonDioxideData()
{
    XML xml = loadXML("EN.ATM.CO2E.PC_Indicator_en.xml");
    XML [] children =  xml.getChildren("data/record");
    
    for(int i=0; i<children.length; i++){ //For each record, get the subtree at field. 
       XML [] fieldArray = children[i].getChildren("field");
       currentCountry = fieldArray[0].getString("key");
       if(!previousCountry.equals(currentCountry)){
         previousCountry = currentCountry;
         countryCounter = countryCounter+1; // go to new row in the 2d array containing the carbondioxide data;
       }   
       
     if(!(trim(fieldArray[3].getContent()).equals(""))){
       dataCO2PerCapita[countryCounter][Integer.parseInt(fieldArray[2].getContent()) - 1960] = Float.parseFloat(fieldArray[3].getContent());
     }else{
       dataCO2PerCapita[countryCounter][Integer.parseInt(fieldArray[2].getContent()) - 1960] = 0;
     }
  }
}

public void loadLatLongData()
{
  String lines[] = loadStrings("CLists.txt");
  XML xml = loadXML("Countries.xml");
  XML [] childrenArray = xml.getChildren("wb:country");
  
  for(int j=0; j<lines.length; j++)
  {
    for(int i=0; i<childrenArray.length; i++)
    {
      if(childrenArray[i].getString("id").equals(lines[j]))
      {
        XML [] subchildrenArrayLati = childrenArray[i].getChildren("wb:latitude");
        XML [] subchildrenArrayLongi = childrenArray[i].getChildren("wb:longitude");
        
        if(!trim(subchildrenArrayLati[0].getContent()).equals(""))
        {
          latLong[j][0] = Float.parseFloat(subchildrenArrayLati[0].getContent());
          latLong[j][1] = Float.parseFloat(subchildrenArrayLongi[0].getContent());
        }
       break;
      }
    }
  }
  
}


public void loadNewsItems()
{
  String [] lines = loadStrings("news.txt");
  
  for(int i=0; i<lines.length; i++)
  {
    String [] chunks = split(lines[i], ';');
    ArrayList chunkList = new ArrayList();
    for (int j=0; j<chunks.length; j++)
    {
      chunkList.add(chunks[j]);
    }
    yearlyNewsList.add(chunkList);
    
  }
}

public void loadCO2TotalData()
{
  String [] lines = loadStrings("CLists.txt");
  XML xml = loadXML("en.atm.co2e.kt_Indicator_en_xml_v2.xml");
  XML [] children = xml.getChildren("data/record");
  
  for(int j =0 ; j<lines.length; j++)
  {
    for(int i=0; i<children.length; i++)
    {
      XML [] fieldArray = children[i].getChildren("field");
     // println("country code is " + fieldArray[0].getString("key"));
      if(fieldArray[0].getString("key").equals(lines[j]))
      {
        if(!trim(fieldArray[3].getContent()).equals(""))
        {
          dataCO2Total[j][Integer.parseInt(fieldArray[2].getContent()) - 1960] = Float.parseFloat(fieldArray[3].getContent());
        }else
        {
          dataCO2Total[j][Integer.parseInt(fieldArray[2].getContent()) - 1960] = 0;
        }
      }
    }
  } 
}

public void loadCountryData()
{
  String lines[] = loadStrings("CLists.txt");
  XML xml = loadXML("Countries.xml");
  XML [] childrenArray = xml.getChildren("wb:country");
  
  for (int j=0; j<lines.length; j++)
  {
    for(int i=0; i<childrenArray.length; i++)
    {
      if(childrenArray[i].getString("id").equals(lines[j]))
      {
        XML [] subChildren = childrenArray[i].getChildren("wb:name");
        if(!trim(subChildren[0].getContent()).equals(""))
        {
          String [] chunks = split(trim(subChildren[0].getContent().toLowerCase()),',');
          countryList.add(chunks[0]);
        }
      }
    }
  }
}

// Each smoke particle is approximated with an image. Gave me denser textures for fewer number of particles in each particle system. 

class Particle{

  PVector loc;
  PImage img;
  PVector vel;
  float lifespan;
  float vxInc ;
  
  Particle(PVector v, PImage img_)
  {
    vxInc = 9.0f;
    float vx = abs(randomGaussian()*0.3f) + vxInc;
    float vy = randomGaussian()*0.2f;
    loc = v.get();
    img = img_;
    vel = new PVector(vx, vy);
    lifespan = 50.0f;
  }

  public void run()
  {
    update();
    render();
  }
  
  public void update()
  {
    loc.add(vel);
    lifespan -= random(1);   
  }
  public void render()
  {
    imageMode(CENTER);
    tint(255, lifespan);
    image(img, loc.x, loc.y);
    tint(255,255);
  }
  
  public boolean isDead()
  {
    if(lifespan <=0.0f) {
      return true;
    }else {
      return false;
    }
  }
  
  public void updatevxInc(float heightOfSmoke)
  {
   float tempVxInc  = heightOfSmoke*0.1f;
   vel.x = vel.x - vxInc + tempVxInc;
   vxInc = tempVxInc;
  }
  
}
class ParticleSystem
{
   ArrayList<Particle>particles; // List to hold the smoke particles
   PVector origin; // The origin of each smoke system
   PImage img; // the image to be used for each smoke particle
   
   ParticleSystem(int num, PVector v, PImage img_)
   {
     particles = new ArrayList<Particle>();
     origin = v.get();
     img = img_;
     for(int i= 0; i<num ; i++)
     {
       particles.add(new Particle(origin, img));
     }
   }
   
   public void run(float heightOfSmoke)
   {
     
     for(int i=particles.size()-1; i>=0; i--)
     {
       Particle p = (Particle)particles.get(i);
       p.updatevxInc(heightOfSmoke*0.1f); // Change the smoke height velocity depending on the data value for each smoke plume.
       p.run();
       if(p.isDead())
       {
         particles.remove(i); // to bring about the smoke fade effect
       }
     }    
   }
   
   public void addParticle()
   {
    particles.add(new Particle(origin,img)); // Keep adding particles so that the smoke is kept alive.
   }
   
   public void changeOrigin(PVector newOrigin)
   {
     origin = newOrigin.get();  
   }
  
}
  public void printCO2()
{
   for(int i=0; i<noOfCountries; i++)
   {
 
    for(int j=0; j<noOfYears; j++)
    {
      print(dataCO2PerCapita[i][j] + " ");
    }
    println("\n");
  }
}

public void printLatLong()
{

 for(int i=0; i<noOfCountries; i++)
 {
   print(i + " ");
    for(int j=0; j<2; j++)
    {
      print(latLong[i][j] + " ");
    }
    println("\n");
  }
}

public void printCountryData()
{
  for(int i=0; i<countryList.size(); i++)
  {
    String eachItem = (String)countryList.get(i);
    println(eachItem);
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--full-screen", "--bgcolor=#666666", "--stop-color=#cccccc", "CarbonDioxideVisualization" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
